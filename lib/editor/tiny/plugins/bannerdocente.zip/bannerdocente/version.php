<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'tiny_banner_uapa';
$plugin->version   = 2024010101;
$plugin->requires  = 2021051700;
$plugin->maturity  = MATURITY_ALPHA;
$plugin->release   = 'v1.0';
