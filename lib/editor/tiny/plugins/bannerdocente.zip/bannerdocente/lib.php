<?php

namespace tiny_banner_uapa;

defined('MOODLE_INTERNAL') || die();

use editor_tiny\plugin;

class plugin extends plugin {
    /**
     * Define the configuration for the editor side (JS).
     *
     * @param \context $context
     * @return array
     */
    public function get_plugin_configuration_for_editor(\context $context): array {
        return [
            'btnTitle' => get_string('header_name', 'tiny_bannerdocente'),
        ];
    }
}
