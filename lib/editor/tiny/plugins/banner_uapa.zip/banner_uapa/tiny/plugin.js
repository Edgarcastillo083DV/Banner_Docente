export default (instance, options) => {
    console.log('TinyMCE UAPA loaded!', instance, options);

    // Registrar el icono SVG (simple)
    instance.ui.registry.addIcon('tiny_banner_uapa', '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="2" y="4" width="20" height="16" rx="2" stroke="currentColor" stroke-width="2"/><circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="2"/></svg>');

    // Definir la acción común
    const openDataDialog = () => {
        // Acción temporal: Alerta para verificar que funciona
        // Luego lo cambiaremos por abrir el formulario
        window.alert('¡Funciona! Aquí irá el formulario de Banners.');
    };

    // Registrar el botón
    instance.ui.registry.addButton('tiny_banner_uapa', {
        icon: 'tiny_banner_uapa',
        tooltip: options.btnTitle,
        onAction: openDataDialog
    });

    // Registrar el elemento de menú
    instance.ui.registry.addMenuItem('tiny_banner_uapa', {
        icon: 'tiny_banner_uapa',
        text: options.btnTitle,
        onAction: openDataDialog
    });
};
