<?php
$string['pluginname'] = 'Tiny Banner UAPA';
$string['header_name'] = 'Insertar Banner';
