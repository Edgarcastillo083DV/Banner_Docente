<?php
$string['pluginname'] = 'Tiny Banner Docente';
$string['header_name'] = 'Insertar Banner Docente';
