<?php
defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Tiny Banner Docente';
$string['header_name'] = 'Insertar Banner Docente';
