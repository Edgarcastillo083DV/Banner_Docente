<?php
$string['pluginname'] = 'Tiny Banner Docente';
$string['header_name'] = 'Insertar Banner Docente';
$string['bannerdocente:view'] = 'Ver botón de Banner Docente';
