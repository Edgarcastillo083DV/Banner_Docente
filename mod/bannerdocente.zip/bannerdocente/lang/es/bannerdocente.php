<?php

$string['pluginname'] = 'Banner Docente UAPA';
$string['modulename'] = 'Banner Docente';
$string['modulename_help'] = 'Use este módulo para insertar un banner visual estandarizado en su curso.';
$string['modulenameplural'] = 'Banners Docentes';
$string['bannername'] = 'Título del banner';
$string['banner_content'] = 'Contenido del Banner';
$string['bannerimage'] = 'Imagen de fondo';
$string['bannerimage_help'] = 'Suba la imagen que servirá de fondo para el banner.';
$string['backgroundcolor'] = 'Color de fondo';
$string['bannertext'] = 'Texto principal';
