<?php

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'mod_bannerdocente';
$plugin->version   = 2026011514;       // The current module version (Date: YYYYMMDDXX)
$plugin->requires  = 2022041900;       // Requires this Moodle version
$plugin->maturity  = MATURITY_ALPHA;
$plugin->release   = 'v0.1';
