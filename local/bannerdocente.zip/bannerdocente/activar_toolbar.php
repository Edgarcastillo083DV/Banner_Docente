<?php
// Script para forzar la configuración de la barra de herramientas de TinyMCE
// Subir a: local/bannerdocente/activar_toolbar.php
// Ejecutar: tudominio.com/local/bannerdocente/activar_toolbar.php

require_once('../../config.php');
require_login();
require_capability('moodle/site:config', context_system::instance());

$PAGE->set_url(new moodle_url('/local/bannerdocente/activar_toolbar.php'));
$PAGE->set_context(context_system::instance());
$PAGE->set_title('Activar Banner UAPA');
$PAGE->set_heading('Configuración Forzada TinyMCE');

echo $OUTPUT->header();

$plugin = 'editor_tiny';
$config = get_config($plugin);

echo "<h2>Configuración Actual de '$plugin'</h2>";

// Buscar dónde está la barra
$toolbar_key = false;
$current_toolbar = '';

// Posibles nombres de la opción en base a versiones
$candidates = ['toolbar', 'editor_toolbar', 'customtoolbar', 'toolbar_settings', 'rows'];

foreach ($config as $key => $value) {
    // Si contiene botones comunes o parece una lista de botones, es la barra
    if (is_string($value) && (strpos($value, 'bold') !== false || strpos($value, 'link') !== false)) {
        $toolbar_key = $key;
        $current_toolbar = $value;
        break;
    }
}

if ($toolbar_key) {
    echo "<div class='alert alert-info'>Detectada configuración de barra en: <strong>$toolbar_key</strong></div>";
    echo "<div class='card p-3 mb-3'><strong>Valor actual:</strong><br><code>$current_toolbar</code></div>";

    if (strpos($current_toolbar, 'tiny_banner_uapa') !== false) {
        echo "<div class='alert alert-success'>✅ ¡El botón 'tiny_banner_uapa' YA está en la barra!</div>";
        echo "<p>Si no lo ve, purgue caché (Administración > Desarrollo > Purgar caché).</p>";
    } else {
        echo "<div class='alert alert-warning'>⚠️ El botón NO está presente.</div>";

        // Botón para corregir
        if (optional_param('fix', 0, PARAM_BOOL)) {
            // Añadirlo al final
            $new_toolbar = trim($current_toolbar);
            // Asegurarse de que haya coma si no está vacío
            if (!empty($new_toolbar) && substr($new_toolbar, -1) != ',') {
                $new_toolbar .= ',';
            }
            $new_toolbar .= 'tiny_banner_uapa';

            set_config($toolbar_key, $new_toolbar, $plugin);

            echo "<div class='alert alert-success'>✅ ¡Actualizado correctamente!</div>";
            echo "<div class='card p-3 mb-3'><strong>Nuevo valor:</strong><br><code>$new_toolbar</code></div>";
            echo "<p><strong>Siguientes pasos:</strong></p>";
            echo "<ol><li>Purgue todas las cachés ahora mismo.</li><li>Vaya al editor y verifique.</li></ol>";
            echo $OUTPUT->single_button(new moodle_url('/admin/purgecaches.php'), 'Ir a Purgar Cachés');
        } else {
            $url = new moodle_url('/local/bannerdocente/activar_toolbar.php', ['fix' => 1]);
            echo $OUTPUT->single_button($url, 'FIX: Añadir tiny_banner_uapa a la barra ahora');
        }
    }
} else {
    echo "<div class='alert alert-danger'>❌ No pude detectar automáticamente qué opción controla la barra.</div>";
    echo "<p>Mostrando toda la configuración detectada para debug:</p>";
    echo "<pre>";
    print_r($config);
    echo "</pre>";
}

echo $OUTPUT->footer();
