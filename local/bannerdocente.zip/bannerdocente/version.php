<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_bannerdocente';
$plugin->version   = 2024010100;
$plugin->requires  = 2021051700; // Moodle 3.11+
$plugin->maturity  = MATURITY_ALPHA;
$plugin->release   = 'v1.0';
