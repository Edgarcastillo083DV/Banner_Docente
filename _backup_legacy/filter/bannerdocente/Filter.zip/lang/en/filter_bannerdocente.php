<?php
$string['filtername'] = 'Teacher Banner Viewer';
