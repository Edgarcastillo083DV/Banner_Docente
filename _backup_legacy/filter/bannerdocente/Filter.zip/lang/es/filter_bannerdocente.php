<?php
$string['filtername'] = 'Visualizador de Banner Docente';
