<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'filter_bannerdocente';
$plugin->version   = 2024010100;
$plugin->requires  = 2021051700;
$plugin->maturity  = MATURITY_ALPHA;
$plugin->release   = 'v1.0';
$plugin->dependencies = array('local_bannerdocente' => 2024010100);
